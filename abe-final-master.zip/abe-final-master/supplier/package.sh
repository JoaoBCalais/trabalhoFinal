cd catalog
./mvnw package
cd ../order
./mvnw package
cd ../supplier-gateway
./mvnw package
cd ../supplier-notification
./mvnw package