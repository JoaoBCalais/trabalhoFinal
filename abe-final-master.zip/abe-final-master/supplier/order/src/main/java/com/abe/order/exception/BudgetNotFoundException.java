package com.abe.order.exception;

public class BudgetNotFoundException extends Error {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3001240400276170309L;

	public BudgetNotFoundException(String string) {
		super(string);
	}

}
