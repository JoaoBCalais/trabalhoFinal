package com.abe.order.exception;

public class OrderNotFoundException extends Error {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1473210737846101333L;

	public OrderNotFoundException(String string) {
		super(string);
	}

}
