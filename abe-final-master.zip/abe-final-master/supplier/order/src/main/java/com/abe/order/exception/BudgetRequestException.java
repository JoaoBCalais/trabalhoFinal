package com.abe.order.exception;

public class BudgetRequestException extends Error {
	/**
	 * 
	 */
	private static final long serialVersionUID = -4579645096360538551L;
	
	public BudgetRequestException(String string) {
		super(string);
	}

}
