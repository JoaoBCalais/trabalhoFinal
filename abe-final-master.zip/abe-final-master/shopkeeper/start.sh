# start.sh
java -jar stock.jar &
java -jar notification.jar &
java -jar gateway.jar