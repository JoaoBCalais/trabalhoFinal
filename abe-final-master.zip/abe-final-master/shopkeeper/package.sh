cd shopkeeper-gateway
./mvnw package
cd ../shopkeeper-notification
./mvnw package
cd ../stock
./mvnw package